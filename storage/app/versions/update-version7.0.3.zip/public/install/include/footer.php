<!-- /.End of page wrapper -->
<footer class="footer text-center">
    <div class="container">
        <div class="fText">Developed by <a href="https://www.bdtask.com/" target="_blank">bdtask</a></div>
    </div>
</footer>
<!-- /.End of footer -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="./public/install/assets/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="./public/install/assets/js/bootstrap.min.js"></script>
<script src="./public/install/assets/js/axios.min.js"></script>
<script src="./public/install/assets/js/main.min.js"></script>
</body>

</html>